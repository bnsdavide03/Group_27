import java.util.Random;

public class StateMachine {
	private int lives;
	private int points;
	private State currentState;
	private boolean newGame;

	public StateMachine() {
		this.lives = 2;
		this.points = 0;
		this.currentState = State.INIT;
		this.newGame = false;
	}

	public void play() {
		Random random = new Random();

		do {
			switch (currentState) {
			case INIT:
				newGame = true;
				currentState = State.PLAY;
				break;

			case PLAY:
				int number = random.nextInt(4);
				evaluateDice(number);
				if (lives <= 0) {
					currentState = State.LOST;
				}
				if (points >= 15) {
					currentState = State.WIN;
				}
				break;

			case LOST:
				newGame = false;
				System.out.println("You lost...");
				break;

			case WIN:
				newGame = false;
				System.out.println("You won!! Your score is: " + points);
				break;
			}
		} while (newGame);
	}

	/**
	 * Per inserire l'ouput della console nel file "Log.txt":
	 * tasto destro sulla classe Main -> Run as... -> Run configurations...
	 * Selezionare la schema "Common" dalle >> vicino alla scheda "Environment"
	 * e spuntare la voce "Output file" indicando il percorso del file
	 */
	private void evaluateDice(int number) {
		System.out.print("Number " + number);

		switch (number) {

		case 0:
			lives--;
			points -= 2;
			break;

		case 1:
			points++;
			break;

		case 2:
			points--;
			break;

		case 3:
			lives++;
			points += 2;
			break;
		}

		System.out.println("; Lives = " + lives + "; Points: " + points);
	}

}

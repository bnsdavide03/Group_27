
public class Main {

	public static void main(String[] args) {
		StateMachine stateMachine = new StateMachine();
		stateMachine.play();
	}

}


public enum State {
	INIT,
	PLAY,
	WIN,
	LOST
}

import java.io.FileNotFoundException;

public class Main {
	public static void main(String[] args) throws FileNotFoundException {
		OutputEvaluator outputEval = new OutputEvaluator();
		outputEval.readFile();
		outputEval.computeResults();
	}
}

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class OutputEvaluator {
	List<String> outputLines;

	public OutputEvaluator() {
		outputLines = new ArrayList<>();
	}

	public void readFile() throws FileNotFoundException {
		File file = new File("./resources/Output.txt");
		Scanner scanner = new Scanner(file);
		
		while (scanner.hasNext()) {
			outputLines.add(scanner.nextLine());
		}

		scanner.close();
	}

	public void computeResults() {
		int zeroCounter = 0;
		int maxLives = 0;
		boolean isNegativePoints = false;

		for (String str : outputLines) {
			String[] components = str.split(";");

			String number = components[0];
			String lives = components[1];
			String points = components[2];

			// number analysis
			String[] numberComponents = number.split(" ");
			int extNumber = Integer.parseInt(numberComponents[1].replace(" ", ""));
			if (extNumber == 0) {
				zeroCounter++;
			}

			// lives analysis
			String[] livesComponents = lives.split("=");
			int extLife = Integer.parseInt(livesComponents[1].replace(" ", ""));
			if (maxLives < extLife) {
				maxLives = extLife;
			}

			// points analysis
			if (!isNegativePoints) {
				String[] pointsComponents = points.split(":");
				int extPoint = Integer.parseInt(pointsComponents[1].replace(" ", ""));
				if (extPoint < 0) {
					isNegativePoints = true;
				}
			}
		}
		System.out.println("Il numero 0 è stato generato " + zeroCounter + " volte.");
		System.out.println("Il numero massimo di vite raggiunte è: " + maxLives);
		if (isNegativePoints) {
			System.out.println("C'è stato almeno un punteggio negativo");
		} else {
			System.out.println("Solo punteggi positivi");
		}
	}

}

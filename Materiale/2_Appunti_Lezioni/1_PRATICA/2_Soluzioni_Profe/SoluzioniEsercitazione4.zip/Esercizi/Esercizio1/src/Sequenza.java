import java.io.File;
import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.Scanner;

public class Sequenza {
	private int[] listaNumeri;
	private int size;

	public Sequenza(int size) {
		this.size = size;
		listaNumeri = new int[size];
	}

	/**
	 * Creazione folder: tasto destro sul progetto -> New -> Folder 
	 * Creazione file: tasto destro sul folder -> New -> File (specificare l'estensione)
	 */
	public void readSequenceFromFile() throws FileNotFoundException {
		//Path del file da leggere
		File file = new File("./resources/MySequenceFile.txt");
		Scanner scanner = new Scanner(file);
		int i = 0;

		while (scanner.hasNext()) {
			listaNumeri[i] = scanner.nextInt();
			i++;
		}

		scanner.close();
	}

	public int computeMin() {
		int min = listaNumeri[0];

		for (int i = 1; i < size; i++) {
			if (listaNumeri[i] < min) {
				min = listaNumeri[i];
			}
		}

		return min;
	}

	public int computeMax() {
		int max = listaNumeri[0];

		for (int i = 1; i < size; i++) {
			if (listaNumeri[i] > max) {
				max = listaNumeri[i];
			}
		}

		return max;
	}

	public int computeSum() {
		int sum = 0;

		for (int i = 0; i < size; i++) {
			sum += listaNumeri[i];
		}
		return sum;
	}

	public float computeMeanValue() {
		int sum = computeSum();

		float mean = (float) sum / size;

		return mean;
	}

	public String getListaNumeri() {
		return Arrays.toString(listaNumeri);
	}
}

import java.io.IOException;

public class Main {

	public static void main(String[] args) throws IOException {
		Sequenza seq = new Sequenza(8);
		
		//Lettura sequenza da file
		seq.readSequenceFromFile();
		System.out.println("Sequenza letta: " + seq.getListaNumeri());
		
		//Calcolo minimo
		System.out.println("Minimo: " + seq.computeMin());
		
		//Calcolo massimo
		System.out.println("Massimo: " + seq.computeMax());
		
		//Calcolo somma
		System.out.println("Somma: " + seq.computeSum());
		
		//Calcolo media
		System.out.println("Media: " + seq.computeMeanValue());
	}

}

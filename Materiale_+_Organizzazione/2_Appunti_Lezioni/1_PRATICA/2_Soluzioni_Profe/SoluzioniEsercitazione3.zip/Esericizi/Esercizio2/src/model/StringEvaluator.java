package model;

public class StringEvaluator {
	private String word;

	public StringEvaluator(String word) {
		this.word = word;
	}

	public void computeStatistics() {
		int capitalLetters = 0;
		int lowerCaseLetters = 0;
		int digits = 0;
		boolean invalidCharacterFound = false;

		for (int i = 0; i < word.length(); i++) {
			char character = word.charAt(i);

			if (Character.isLetterOrDigit(character)) {
				// valid character
				if (Character.isLetter(character)) {
					// letter
					if (Character.isUpperCase(character)) {
						capitalLetters++;
					}

					if (Character.isLowerCase(character)) {
						lowerCaseLetters++;
					}
				}

				if (Character.isDigit(character)) {
					// digit
					digits++;
				}
			} else {
				System.out.println("Invalid character found: " + character);
				invalidCharacterFound = true;
				break;
			}
		}

		if (!invalidCharacterFound) {
			System.out
					.println("Maiuscole: " + capitalLetters + " Minuscole: " + lowerCaseLetters + " Cifre: " + digits);

			int stringLength = word.length();

			System.out.println(((double) capitalLetters) / stringLength * 100 + "% maiuscole, "
					+ lowerCaseLetters / (double) stringLength * 100 + "% minuscole, "
					+ digits / (double) stringLength * 100 + "% cifre ");
		}
	}
}

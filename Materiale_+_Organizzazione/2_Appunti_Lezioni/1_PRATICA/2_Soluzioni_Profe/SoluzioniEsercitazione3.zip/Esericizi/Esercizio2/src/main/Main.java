package main;

import java.util.Scanner;

import model.StringEvaluator;

public class Main {

	public static void main(String[] args) {

		// Lettura input
		Scanner scanner = new Scanner(System.in);
		String inputString;

		do {
			System.out.println("Inserire una stringa alfanumerica di 10 caratteri: ");
			inputString = scanner.nextLine();
		} while (inputString.length() != 10);
		
		scanner.close();
		
		StringEvaluator stringEvaluator = new StringEvaluator(inputString);
		stringEvaluator.computeStatistics();
	}

}

package model;

public class NumeroPrimo {
	private int numero;

	public NumeroPrimo(int numero) {
		this.numero = numero;
	}

	public void forCheck() {
		int counter = 0;

		for (int i = 1; i <= numero; i++) {
			if (numero % i == 0) {
				counter++;
			}
		}
		
		if(counter == 2) {
			System.out.println(numero + " è primo");
		}else {
			System.out.println(numero + " non è primo e ha " + counter + " divisori");
		}
	}
	
	public void whileCheck() {
		int counter = 0;
		int temp = numero;
		
		while(temp > 0) {
			if (numero % temp == 0) {
				counter++;
			}
			temp--;
		}
		
		if(counter == 2) {
			System.out.println(numero + " è primo");
		}else {
			System.out.println(numero + " non è primo e ha " + counter + " divisori");
		}
	}
	
	public void forWithBreakCheck() {
		int counter = 0;

		for (int i = 1; i <= numero; i++) {
			if (numero % i == 0) {
				counter++;
			}
			
			if(counter > 2) {
				break;
			}
		}
		
		if(counter == 2) {
			System.out.println(numero + " è primo");
		}else {
			System.out.println(numero + " non è primo");
		}
	}
}

package main;

import java.util.Scanner;

import model.NumeroPrimo;

public class Main {
	public static void main(String[] args) {
		
		//Lettura input
		Scanner scanner = new Scanner(System.in);		
		System.out.println("Inserire un numero intero: ");	
		int numeroLetto = scanner.nextInt();
		scanner.close();
		
		NumeroPrimo numeroPrimo = new NumeroPrimo(numeroLetto);
		numeroPrimo.forCheck();
		numeroPrimo.whileCheck();
		numeroPrimo.forWithBreakCheck();
	}
}

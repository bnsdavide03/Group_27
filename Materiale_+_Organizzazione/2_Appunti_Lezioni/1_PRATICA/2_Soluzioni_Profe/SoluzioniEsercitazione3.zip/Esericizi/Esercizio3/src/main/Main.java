package main;

import java.util.Scanner;

import model.Equazione;

public class Main {

	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Inserire il coefficiente a: ");
		int a = scanner.nextInt();
		
		System.out.println("Inserire il coefficiente b: ");
		int b = scanner.nextInt();
		
		System.out.println("Inserire il coefficiente c: ");
		int c = scanner.nextInt();
		
		if(a == 0) {
			System.out.println("L'equazione inserita non è di secondo grado: a = 0");
		}else if(b == 0 && c!=0) {
			Equazione.pura(a,c);
		}else if(b != 0 && c == 0) {
			Equazione.spuria(a,b);
		}else if(b != 0 && c!= 0) {
			Equazione.completa(a,b,c);
		}
		scanner.close();
	}

}

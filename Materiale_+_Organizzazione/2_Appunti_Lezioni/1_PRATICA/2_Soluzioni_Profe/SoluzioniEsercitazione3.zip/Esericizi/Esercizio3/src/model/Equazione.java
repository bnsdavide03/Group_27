package model;

public class Equazione {

	public static void pura(int a, int c) {
		System.out.println(a + "x^2 + " + c + " = 0");
		if (a * c > 0) {
			System.out.println("Equazione impossibile S = {}");
		} else {
			double res = Math.sqrt(-c / (double) a);
			System.out.println("Equazione determinata S = {" + -res + ", " + res + "}");
		}
	}

	public static void spuria(int a, int b) {
		System.out.println(a + "x^2 + " + b + " x = 0");
		System.out.println("Equazione determinata S = {" + 0 + ", " + -b / (double) a + "}");
	}

	public static void completa(int a, int b, int c) {
		System.out.println(a + "x^2 + " + b + " x + " + c + " = 0");
		double delta = (b*b) - (4 * a * c);
		double sol1;
		double sol2;

		if (delta > 0) {
			sol1 = (-b - delta) / (2.0 * a);
			sol2 = (-b + delta) / (2.0 * a);
			System.out.println("Equazione determinata S = {" + sol1 + ", " + sol2 + "}");
		} else if (delta == 0) {
			sol1 = -b / (2.0 * a);
			System.out.println("Equazione determinata S = {" + sol1 + "}");
		} else {
			System.out.println("Equazione impossibile S = {}");
		}
	}

}
